import 'package:angular/angular.dart';

// AngularDart info: https://angulardart.dev
// Components info: https://angulardart.dev/components

@Component(
  selector: 'my-app',
  styleUrls: ['app_component.css'],
  directives: [coreDirectives],
  template: '''
  <h1 [ngStyle]="{'color': counter >= 1000 ? 'green' : 'grey'}"> Bank account: {{ counter }}  </h1>
  <p *ngIf="counter >= 1000">I am rich!</p>
  <button (click)="makeMoney()">Make Money!</button>
  
  '''
//  templateUrl: 'app_component.html',

)
class AppComponent {
   final title = 'Make It Rain';
   int counter = 0;

   void makeMoney() {
      counter += 100;
      print(counter);

   }




}
