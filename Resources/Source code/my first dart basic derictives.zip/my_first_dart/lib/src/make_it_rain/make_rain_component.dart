import 'package:angular/angular.dart';


@Component(
   selector: 'make-rain',
   styleUrls: ['make_rain_component.css'],
  templateUrl: 'make_rain_component.html',
  directives: [coreDirectives]
)
class MakeRainComponent {

  final title = 'Make It Rain';
  int counter = 0;

  void makeMoney() {
    counter += 100;
    print(counter);

  }

}