
import 'package:angular/angular.dart';

@Component(
  selector: 'learn-direct',
  templateUrl: 'learn_direct_component.html',
  styleUrls: ['learn_direct_component.css'],
  directives: [coreDirectives]
)
class LearnDirectComponent {
  final title = 'Learn Directives';
  bool isVisible = false;
  bool isSpecial = false;

  List students;

  Map<String, String> myStyles = <String, String>{};
  void setMyStyles() {
    myStyles = <String, String> {
      'font-style': isSpecial ? 'italic' : 'normal',
      'font-size' : !isSpecial ? '34px' : '12px',
      'font-weight' : isSpecial ? 'bold' : 'normal'
    };
  }

  Object trackByStudentId(_, dynamic o) => o is Student ? o.id : o;

  void getStudents() {
   students = [
      Student(1, 'Paulo James'),
      Student(2, 'Carlos Santana'),
      Student(3, 'Carlos Diego'),
      Student(4, 'Bonni Ilia')
    ];

  }


  void toggleVisible() {
     //isVisible = !isVisible;
    setMyStyles();
  }

}

class Student {
   int id;
   String name;

   Student(this.id, this.name);

}