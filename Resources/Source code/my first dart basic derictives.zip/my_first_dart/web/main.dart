import 'package:angular/angular.dart';
import 'package:my_first_dart/app_component.template.dart' as ng;

void main() {
  runApp(ng.AppComponentNgFactory);
}
