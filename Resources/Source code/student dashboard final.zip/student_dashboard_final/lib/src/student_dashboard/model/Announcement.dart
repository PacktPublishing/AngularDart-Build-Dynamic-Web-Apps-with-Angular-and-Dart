class Announcement {
   int id;
   String title;
   String description;

   Announcement(this.id, this.title, this.description);

}