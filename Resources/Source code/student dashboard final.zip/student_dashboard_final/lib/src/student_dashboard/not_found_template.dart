import 'package:angular/angular.dart';


@Component(
  selector: 'my-not-found',
  template: '<h1>Page Not Found! </h1>'
)
class NotFoundComponent {

}